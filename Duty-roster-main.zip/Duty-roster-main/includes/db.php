<?php

/* This program is written by Hertzsoft Technologies Pvt. Ltd.
Last Modified: 2021-03-19 00:17:03

Description:
This file contains server details. Kindly change the details in this file before hosting
*/

//  -------------- DATABASE CONFIGURATIONS (LOCALHOST) -------------- 
define("SERVER","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","dutyroaster");

?>